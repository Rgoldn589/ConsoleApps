﻿namespace ReverseLettersInEachWordInString
{
    /// <summary>
    /// Revers the letters in each word of a string
    /// </summary>
    public class Program
    {
        private const string INPUT = "The quick brown fox jumped under the nearby tree. What the fox " +
                                   "did next suprised the crowd. The silence was followed by the applause. " +
                                   "Applause that lasted for minutes. The fox blushed under the tree.";

        static void Main(string[] args)
        {
            var split = INPUT.Split(" ");
            var result = string.Empty;

            foreach (var item in split) 
            {
                var rev = item.Reverse();

                foreach(var letter in rev) 
                    result += letter;

                result += " ";
            }


            Console.WriteLine(result);
        }
    }
}