﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace Program
{
    public class Program
    {
        /// <summary>
        /// Counts the number of duplicate words in a string.
        /// </summary>
        private const string INPUT = "The quick brown fox jumped under the nearby tree. What the fox " +
                                     "did next suprised the crowd. The silence was followed by the applause. " +
                                     "Applause that lasted for minutes. The fox blushed under the tree.";
        static void Main(string[] args)
        {
            string[] split = INPUT.ToUpper().Replace('.', ' ').Split(' ');
            string used = string.Empty;

            foreach (string word in split) 
            {
                if (used.Contains(word)) { continue; }

                var duplicates = split.Where(x => x.Contains(word)).ToList();

                if (duplicates.Count > 1)
                {
                    string output = word + ": " + duplicates.Count;
                    Console.WriteLine(output);
                    used += word;
                }

            }

        }
    }

}
 