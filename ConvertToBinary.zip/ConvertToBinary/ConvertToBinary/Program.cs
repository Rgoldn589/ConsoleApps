﻿public class Program
{
    private const string INPUT = "10";

    static void Main(string[] args)
    {

        string ans = "";
        bool check = false;


        for (int i = 31; i >= 0; i--)
        {
            if ((Int32.Parse(INPUT) & (1 << i)) != 0)
            {
                ans += "1";
                
                if (!check)
                    check = true;
            }
            else
            {
                if (!check)
                    continue;

                ans += "0";
            }
        }

        Console.WriteLine(ans);
    }
}
