﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;


namespace Program
{
    public class Program
    {
        private const string INPUT = "The quick brown fox jumped under the nearby tree. What the fox " +
                                   "did next suprised the crowd. The silence was followed by the applause. " +
                                   "Applause that lasted for minutes. The fox blushed under the tree.";
        static void Main(string[] args)
        {

            string[] words = INPUT.Split(" ");
            var reverseWords = words.Reverse();

            //Reverse Words in a sentence
            Console.WriteLine("********************");
            Console.WriteLine("  Reverse Sentence  ");
            Console.WriteLine("********************");

            foreach (string word in reverseWords)
                Console.WriteLine(word);

            //Reverse letters in a word.
            Console.WriteLine("   ");
            Console.WriteLine("   ");
            Console.WriteLine("********************");
            Console.WriteLine("  Reverse Word      ");
            Console.WriteLine("********************");

            foreach (string word in words)
            {
                string wordReversed = string.Empty;
                char[] chars = word.ToCharArray();
                var charsReversed = chars.Reverse();

                foreach (char c in charsReversed) 
                {
                    wordReversed += c;
                }

                Console.WriteLine(wordReversed);
            }
        }
    }
}